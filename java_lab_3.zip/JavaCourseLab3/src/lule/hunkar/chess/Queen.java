package lule.hunkar.chess;

/**
 * Class to create queen objects. It has only non-argument constructor.
 * 
 * @author Hunkar Lule
 *
 */
public class Queen extends ChessPiece {
	public final static int VALUE_OF_QUEEN = 9;

	/**
	 * Constructs queen. It calls parent's class constructor with the constant
	 * (VALUE_OF_QUEEN)
	 */
	public Queen() {
		super(VALUE_OF_QUEEN);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Queen [getValue()=" + getValue() + "]";
	}

	/**
	 * Overrides move() method of parent ChessPiece class. It prints the move of a
	 * queen in the chess game.
	 */
	@Override
	public void move() {
		System.out.println("like a bishop or a rook");
	}
}
