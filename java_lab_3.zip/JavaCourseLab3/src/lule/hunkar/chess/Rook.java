package lule.hunkar.chess;

/**
 * Class to create rook objects. It has only non-argument constructor.
 * 
 * @author Hunkar Lule
 *
 */
public class Rook extends ChessPiece {
	public final static int VALUE_OF_ROOK = 5;

	/**
	 * Constructs knight. It calls parent's class constructor with the constant
	 * (VALUE_OF_ROOK)
	 */
	public Rook() {
		super(VALUE_OF_ROOK);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Rook [getValue()=" + getValue() + "]";
	}

	/**
	 * Overrides move() method of parent ChessPiece class. It prints the move of a
	 * rook in the chess game.
	 */
	@Override
	public void move() {
		System.out.println("horizontally or vertically");
	}
}
