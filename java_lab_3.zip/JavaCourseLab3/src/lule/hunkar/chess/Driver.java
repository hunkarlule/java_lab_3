package lule.hunkar.chess;

public class Driver {
	public static void main(String[] args) {
		System.out.println("\n=====1st Test for promote() method=====");
		Pawn firstPawn = new Pawn();
		ChessPiece rook = new Rook();
		System.out.println("\n=====firstPawn before promotion=====");
		System.out.println(firstPawn);

		// promoting firstPawn to rook
		firstPawn.promote(rook);
		System.out.println("\n=====firstPawn after promotion- promoted to Rook=====");
		System.out.println(firstPawn);

		System.out.println("\n=====2nd Test for promote() method=====");
		// trying to promote firstPawn to bishop but we already promoted it
		// Therefore we could not promote it again. Nothing changed!!
		ChessPiece bishop = new Bishop();
		System.out.println("\n=====firstPawn after promotion-nothing changed=====");
		System.out.println(firstPawn);

		// Tyring to pormote a pawn(secondPawn) to a King.
		// Because we could not promote a pawn to a king. Nothing changes!!
		System.out.println("\n=====3rd Test for promote() method=====");
		Pawn secondPawn = new Pawn();
		ChessPiece king = new King();

		System.out.println("\n=====secondPawn before promotion=====");
		System.out.println(secondPawn);

		// trying to secondPawn to promote to King
		secondPawn.promote(king);
		System.out.println("\n=====secondPawn after promotion-nothing changed=====");
		System.out.println(secondPawn);
	}
}
