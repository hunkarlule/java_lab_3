package lule.hunkar.chess;

/**
 * Class to create pawn objects. It has only non-argument constructor.
 * 
 * @author Hunkar Lule
 *
 */
public class Pawn extends ChessPiece {
	public final static int VALUE_OF_PAWN = 1;
	private boolean hasBeenPromoted;
	private ChessPiece newPiece;

	/**
	 * Constructs pawn. It calls parent's class constructor with the constant
	 * (VALUE_OF_PAWN).
	 */
	public Pawn() {
		super(VALUE_OF_PAWN);
	}

	/**
	 * @return the hasBeenPromoted attribute of a pawn object
	 */
	public boolean getHasBeenPromoted() {
		return hasBeenPromoted;
	}

	/**
	 * @return the newPiece attribute of a pawn object.
	 */
	public ChessPiece getNewPiece() {
		return newPiece;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Pawn [hasBeenPromoted=" + hasBeenPromoted + ", newPiece=" + newPiece + ", getValue()=" + getValue()
				+ "]";
	}

	/**
	 * Overrides move() method of parent ChessPiece class. It prints the move of a
	 * pawn in the chess game.
	 */
	@Override
	public void move() {
		System.out.println("forward one");
	}

	/**
	 * Method to promote the pawn to new chess piece. It takes one
	 * argument(newPiece) to whom pawn will be promoted. Method checks pawn is
	 * appropriate to promote. It the argument is king or pawn or pawn then pawn is
	 * not promoted(because pawn can not be promoted to king or to pawn) Also It
	 * checks pawn is already promoted or not. It it is pormoted already then it
	 * does not promote it second time.
	 * 
	 * @param newPiece
	 *            chess piece that pawn will be promoted
	 */
	public void promote(ChessPiece newPiece) {
		if (newPiece != null) {
			if (!(newPiece instanceof King) && !(newPiece instanceof Pawn) && !hasBeenPromoted) {
				this.hasBeenPromoted = true;
				this.newPiece = newPiece;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (hasBeenPromoted ? 1231 : 1237);
		result = prime * result + ((newPiece == null) ? 0 : newPiece.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pawn other = (Pawn) obj;
		if (hasBeenPromoted != other.hasBeenPromoted)
			return false;
		if (newPiece == null) {
			if (other.newPiece != null)
				return false;
		} else if (!newPiece.equals(other.newPiece))
			return false;
		return true;
	}

}
