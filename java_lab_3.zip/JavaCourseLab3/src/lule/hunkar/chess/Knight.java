package lule.hunkar.chess;

/**
 * Class to create knight objects. It has only non-argument constructor.
 * 
 * @author Hunkar Lule
 *
 */
public class Knight extends ChessPiece {
	public final static int VALUE_OF_KNIGHT = 2;

	/**
	 * Constructs knight. It calls parent's class constructor with the constant
	 * (VALUE_OF_KNIGHT)
	 */
	public Knight() {
		super(VALUE_OF_KNIGHT);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Knight [getValue()=" + getValue() + "]";
	}

	/**
	 * Overrides move() method of parent ChessPiece class. It prints the move of a
	 * knight in the chess game.
	 */
	@Override
	public void move() {
		System.out.println("like an L");
	}
}
