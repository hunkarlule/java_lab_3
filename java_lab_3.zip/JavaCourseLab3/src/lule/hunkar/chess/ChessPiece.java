package lule.hunkar.chess;

/**
 * Abstract class for chess pieces. The class a field(value). Also the class
 * provides abstract move() method. Classes that inherits from this class must
 * provide their own implementation for this method.
 * 
 * @author Hunkar Lule
 *
 */
public abstract class ChessPiece {
	private int value;

	/**
	 * Constructs a ChessPiece with specified value.
	 * 
	 * @param value
	 *            that will be assigned to the ChessPiece object's value attribute.
	 */
	public ChessPiece(int value) {
		this.value = value;
	}

	/**
	 * @return the value attribute of the ChessPiece object.
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set the value attribute of ChessPiece object
	 */
	public void setValue(int value) {
		this.value = value;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + value;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object chessPiece) {
		if (chessPiece == null) {
			return false;
		}

		if (chessPiece == this) {
			return true;
		}

		if (!(chessPiece instanceof ChessPiece)) {
			return false;
		}

		ChessPiece other = (ChessPiece) chessPiece;

		return (this.value == other.value);

	}

	/**
	 * Abstract method. Subclasses should provide their implementation.
	 */
	public abstract void move();

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */

	@Override
	public String toString() {
		return "ChessPiece [value=" + value + "]";
	}

}
