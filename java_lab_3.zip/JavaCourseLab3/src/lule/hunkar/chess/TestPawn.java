package lule.hunkar.chess;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.Test;

/**
 * Test class for Pawn class. It tests the Promote() method of Pawn class.
 * 
 * @author Hunkar Lule
 *
 */
public class TestPawn {

	@Test
	public void testPromote() {
		ChessPiece newPiece = new Rook();
		Pawn myPawn = new Pawn();
		myPawn.promote(newPiece);
		assertNotNull(myPawn.getNewPiece());
		assertTrue(myPawn.getHasBeenPromoted());
		assertEquals(newPiece, myPawn.getNewPiece());
	}

	@Test
	public void testNotPromote() {
		ChessPiece king = new King();
		Pawn myPawn = new Pawn();
		myPawn.promote(king);
		assertNull(myPawn.getNewPiece());
		assertFalse(myPawn.getHasBeenPromoted());
	}

	@Test
	public void testPromoteToPawn() {
		ChessPiece pawn = new Pawn();
		Pawn myPawn = new Pawn();
		myPawn.promote(pawn);
		assertNull(myPawn.getNewPiece());
		assertFalse(myPawn.getHasBeenPromoted());
		assertNotEquals(pawn, myPawn.getNewPiece());
	}

	@Test
	public void testPromoteTwice() {
		ChessPiece queen = new Queen();
		Pawn myPawn = new Pawn();
		myPawn.promote(queen);

		assertNotNull(myPawn.getNewPiece());
		assertTrue(myPawn.getHasBeenPromoted());
		assertEquals(queen, myPawn.getNewPiece());
		assertTrue(myPawn.getHasBeenPromoted());
		assertEquals(queen, myPawn.getNewPiece());

		ChessPiece rook = new Rook();
		myPawn.promote(rook);
		assertNotEquals(rook, myPawn.getNewPiece());
		assertNotNull(myPawn.getNewPiece());
		assertEquals(queen, myPawn.getNewPiece());
		assertTrue(myPawn.getHasBeenPromoted());
	}

	@Test
	public void testPromoteToNull() {
		ChessPiece bishop = null;
		Pawn myPawn = new Pawn();
		myPawn.promote(bishop);
		assertNull(myPawn.getNewPiece());
		assertFalse(myPawn.getHasBeenPromoted());
	}
}
