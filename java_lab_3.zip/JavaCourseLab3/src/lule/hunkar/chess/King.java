package lule.hunkar.chess;

/**
 * Class to create king objects. It has only non-argument constructor.
 * 
 * @author Hunkar Lule
 *
 */
public class King extends ChessPiece {
	public final static int VALUE_OF_KING = 1000;

	/**
	 * Constructs king. It calls parent's class constructor with the constant
	 * (VALUE_OF_KING)
	 */
	public King() {
		super(VALUE_OF_KING);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "King [getValue()=" + getValue() + "]";
	}

	/**
	 * Overrides move() method of parent ChessPiece class. It prints the move of a
	 * king in the chess game.
	 */
	@Override
	public void move() {
		System.out.println("one square");
	}

}
