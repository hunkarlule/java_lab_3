package lule.hunkar.chess;

/**
 * Class to create bishop objects. It has only non-argument constructor.
 * 
 * @author Hunkar Lule
 *
 */
public class Bishop extends ChessPiece {
	public final static int VALUE_OF_BISHOP = 3;

	/**
	 * Constructs bichop. It calls parent's class constructor with the constant
	 * (VALUE_OF_BISHOP)
	 * 
	 */
	public Bishop() {
		super(VALUE_OF_BISHOP);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Bishop [getValue()=" + getValue() + "]";
	}

	/**
	 * 
	 */
	@Override
	public void move() {
		System.out.println("diagonally one");
	}
}
